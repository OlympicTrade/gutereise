<?php
namespace SyncAdmin\Controller;

use Aptero\Mvc\Controller\Admin\AbstractActionController;
use Aptero\Service\Admin\TableService;

class SyncController extends AbstractActionController
{

}