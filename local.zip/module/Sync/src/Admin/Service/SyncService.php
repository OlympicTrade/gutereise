<?php
namespace SyncAdmin\Service;

use Aptero\Service\Admin\TableService;

class SyncService extends TableService
{

}