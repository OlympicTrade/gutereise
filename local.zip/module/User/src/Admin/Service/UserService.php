<?php
namespace UserAdmin\Service;

use Aptero\Db\Entity\Entity;
use Aptero\Service\Admin\TableService;

class UserService extends TableService
{

}