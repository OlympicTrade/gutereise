<?php
namespace ContactsAdmin\Service;

use Aptero\Service\Admin\TableService;

class ContactsService extends TableService
{

}