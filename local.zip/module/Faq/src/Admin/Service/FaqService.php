<?php
namespace FaqAdmin\Service;

use Aptero\Service\Admin\TableService;

class FaqService extends TableService
{

}