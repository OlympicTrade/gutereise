<?php
namespace MetricsAdmin\Service;

use Aptero\Service\Admin\TableService;

class AdwordsService extends TableService
{

}