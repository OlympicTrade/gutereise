<?php
namespace ExcursionsAdmin\Service;

use Aptero\Service\Admin\TableService;

class TagsService extends TableService
{

}