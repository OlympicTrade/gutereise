<?php
namespace ExcursionsAdmin\Service;

use Aptero\Service\Admin\TableService;

class ExcursionsService extends TableService
{

}