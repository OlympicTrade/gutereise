<?php
namespace MuseumsAdmin\Controller;

use Aptero\Mvc\Controller\Admin\AbstractActionController;
use Aptero\Service\Admin\TableService;

class PointsController extends AbstractActionController
{

}