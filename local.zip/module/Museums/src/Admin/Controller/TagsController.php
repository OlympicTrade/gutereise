<?php
namespace MuseumsAdmin\Controller;

use Aptero\Mvc\Controller\Admin\AbstractActionController;

class TagsController extends AbstractActionController
{

}