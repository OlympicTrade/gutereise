<?php
namespace MuseumsAdmin\Service;

use Aptero\Service\Admin\TableService;

class MuseumsService extends TableService
{

}