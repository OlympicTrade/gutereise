<?php
namespace MuseumsAdmin\Service;

use Aptero\Service\Admin\TableService;

class PointsService extends TableService
{

}