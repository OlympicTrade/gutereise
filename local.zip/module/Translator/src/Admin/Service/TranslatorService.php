<?php
namespace TranslatorAdmin\Service;

use Aptero\Service\Admin\TableService;

class TranslatorService extends TableService
{

}