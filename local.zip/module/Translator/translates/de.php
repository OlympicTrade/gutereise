<?php return array (
  'ad715b22516dbbe04a5ff7870f346980be15f8d0' => 'Öffnen Sie auf der Website',
  '796f48a47d62dd68e3b65a1f614d4f1cb409a2a7' => 'Antwort',
  'fa463b30c744c02ac63bf0250a9f99e3e79bfbd8' => 'Die Antwort auf die Frage',
  '2263b4741a78594cb2214e4afff277fb7e3bd756' => 'Die Antwort auf Ihre Frage',
  '9e75c7c4c45dbe9c52485c4bfd5b6ff472a450b1' => 'Individuelle Führungen<br> in St. Petersburg',
  '7b148bb0f9ad057510a1bdf70692764e93cb3300' => 'Fragen und Feedback',
  'f71c44288109596084363e252b992ce971dff605' => 'Beschreibung',
  '7bb92b21efd5f82337c2bc75ee7015403d99672f' => 'Buchen',
  'cc0a78d27b5191019db5d2868cd531dd0cf28a4a' => 'Das Museum arbeitet nicht in dieser Zeit des Jahres',
  'b5b78a69a486a7be24710e4a4710f12f8f2d3473' => 'Kinder',
  '217fae81dff8bdb1c7a6db632d5d4720eda3a280' => 'Stunden',
  '973fdd9a355714027bd170b86c6bc271b4498d22' => 'pro Person',
  'c6bd2924aaf400178a2016eaf44d3abe8e37035c' => 'Große Prospekt der Petrograder Seite, das Haus. 100, lit. A, Büro 513',
  '32bee37d30acc404b947a4702cf72d49384d1f0e' => 'alle anzeigen',
  '0273a1685bbcdb606ab0cba9d915bd769d02025d' => 'Buchen',
  '6bf033ad09512507d7391a4b035e04da33e93ecf' => 'Sie werden nicht nur mit den Sälen des Winterpalastes, sondern auch die Meisterwerke der weltweiten Malerei, Skulptur und angewandten Kunst aus verschiedenen Kulturen und Ländern.',
  '568a96f3fd7945d9337a5041de1bf32125caa567' => 'Das Michailowski-Schloss',
  '29cb18e7005809a4268049e69307481254f9bb61' => 'Ausflüge in St. Petersburg',
  '3d1b663710567e842f76c9a1447dc54b3229440f' => 'Ausflüge nach St. Petersburg',
  '30fab6ad904d14044cb04d132c1d9ece4f87ad17' => 'Museen und Kunst',
  'fade0adbf7cd47fd03480039c12ec082ee04d09a' => 'Wir arbeiten seit 2007 auf dem Markt der touristischen Dienstleistungen im Bereich der nationalen und internationalen Outbound-Tourismus. Partner mit denen wir zusammenarbeiten - es ist eine zuverlässige und verantwortungsvolle Organisation.<br> Für uns in der Arbeit gibt es keine Kleinigkeiten, alles, was wir tun, muss dem europäischen Niveau der Qualität.',
  '5f099ffe09454b97adeca925d67c65a6bc1d3ac3' => '<p>Gattschina-Palast und das zu ihm angrenzende Territorium des Parks waren einst die kaiserliche Residenz. Paul I liebte diese Plätze. Er hatte eine Besondere Leidenschaft für alles geheimnisvolle, liebte Burgen, viel Aufmerksamkeit der Sicherheit. Deshalb ist sein Palast in Gatschina so erinnert an die mittelalterliche Burg, in ihm sogar einen echten unterirdischen Gang. Während der Tour sehen Sie die festsäle, Wohnräume und natürlich besuchen Sie die geheimen Kerker; lernen die Geschichte des Schlosses. Das Museum zeigt eine Sammlung von Gemälden und Skulpturen, Möbelstücke, Küchengeräte (insbesondere - Porzellan), Schmuck.</p>

<p>dieses Programm beinhaltet einen Spaziergang durch пейзажному Park Gattschina, wo Sie in der Lage, mit voller Brust atmen die frische Luft und bewundern Sie die malerischen Teiche und Haine, Brücken und Pavillons.</p>

<p>Auf dem Weg vom Hotel zum Gattschina werden Sie eine Vielzahl von Sehenswürdigkeiten, mit denen Sie befasst sich unser Führer.</p>
',
  'cc3379402df15b72383e40e8627c32cd7f33d8cf' => 'Ausflug in das Michailowski-Schloss',
  'ac606e93138dd0755d614d0749c3fd19fa5009da' => 'Ende des Ausflugs',
  '995e304110225e79e1804d3955dfd5b82fd6b1f4' => 'Wie viel extra-Dienstleistungen? Professioneller Fotograf, Saxophonist, Lieferung von Speisen, die Dekoration des Daches des Ballons?',
  '44c4befed98778d3e0e3d7d78fd9929f7566fe97' => 'Titel',
  '22307874c55dd88c4737a545ae0c4969437d170d' => 'Sprache',
  '4338ca1a07b9a0f9ae8f5e3371a1324f29ca86fc' => 'Achtung',
  '24b45e86d53972809ab379abd6b5fbab65260cf2' => 'Hände hoch',
  '9660a82876a81a983eb45391928d948fb19f6e94' => 'Hitler Kaput',
  '4166d94fda800fdf4aaecc94735ec4241403f707' => 'Schwein',
);