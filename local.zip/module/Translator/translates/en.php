<?php return array (
  'ad715b22516dbbe04a5ff7870f346980be15f8d0' => 'To access the website',
  '796f48a47d62dd68e3b65a1f614d4f1cb409a2a7' => 'The answer',
  'fa463b30c744c02ac63bf0250a9f99e3e79bfbd8' => 'The answer to the question',
  '2263b4741a78594cb2214e4afff277fb7e3bd756' => 'Received an answer to your question',
  '9e75c7c4c45dbe9c52485c4bfd5b6ff472a450b1' => 'Private Tours<br>in St. Petersburg',
  '7b148bb0f9ad057510a1bdf70692764e93cb3300' => 'Questions and feedback',
  'f71c44288109596084363e252b992ce971dff605' => 'Description',
  '7bb92b21efd5f82337c2bc75ee7015403d99672f' => 'Book',
  'cc0a78d27b5191019db5d2868cd531dd0cf28a4a' => 'The Museum closes for the season',
  'b5b78a69a486a7be24710e4a4710f12f8f2d3473' => 'Children',
  '217fae81dff8bdb1c7a6db632d5d4720eda3a280' => 'hours',
  '973fdd9a355714027bd170b86c6bc271b4498d22' => 'per person',
  'c6bd2924aaf400178a2016eaf44d3abe8e37035c' => 'Bolshoi Prospekt Petrograd side, home. 100, lit. A, office 513',
  '32bee37d30acc404b947a4702cf72d49384d1f0e' => 'show all',
  '0273a1685bbcdb606ab0cba9d915bd769d02025d' => 'Order',
  '6bf033ad09512507d7391a4b035e04da33e93ecf' => 'You will see not only the state rooms of the Winter Palace, but also see the masterpieces of world painting, sculpture and applied art of different cultures and countries.',
  '568a96f3fd7945d9337a5041de1bf32125caa567' => 'The Mikhailovsky castle',
  '29cb18e7005809a4268049e69307481254f9bb61' => '<br>Excursions in Saint-Petersburg',
  '3d1b663710567e842f76c9a1447dc54b3229440f' => 'Of excursion',
  '30fab6ad904d14044cb04d132c1d9ece4f87ad17' => 'Museums and art',
  'fade0adbf7cd47fd03480039c12ec082ee04d09a' => 'We have been working since 2007 in the market of tourist services in the field of domestic and international outbound tourism.<br>Partners with whom we cooperate are reliable and responsible organizations. For us there are no trifles in the work, everything that we do must comply with the European level of quality.',
  '5f099ffe09454b97adeca925d67c65a6bc1d3ac3' => '<p>Gatchina Palace&#39; and the adjacent Park was once an Imperial residence. Paul I loved this place. He had a special passion for everything mysterious, adored locks, paid a lot of attention to security. That&#39;s why his Palace in Gatchina is so reminiscent of a medieval castle, it even has a real underground passage. During the tour You will see the state rooms, living rooms and of course visit the secret cave; learn about the history of the Palace. The Museum presents the collection of painting and sculpture, furniture, kitchen utensils (in particular porcelain), jewelry.</p>

<p>The program includes a walk through the landscape Park of Gatchina, where you full chest can breathe fresh air and enjoy the scenic ponds and trees, bridges and pavilions.</p>

<p>On the way from the hotel to Gatchina You will see a variety of sights that will introduce You to our guide.</p>
',
  'cc3379402df15b72383e40e8627c32cd7f33d8cf' => 'Tour of the Mikhailovsky castle',
  'ddc20511538e5e97b5af4e64ad0bf6b4ddf9f67c' => 'Jonesy what Jonesy what Jonesy what few afyv Aviv Aviv afy Vafa VA',
  'ac606e93138dd0755d614d0749c3fd19fa5009da' => 'The end of the tour',
  '995e304110225e79e1804d3955dfd5b82fd6b1f4' => 'How much are extra services? Professional photographer, saxophonist, meals, a roof decoration balloons?',
  '44c4befed98778d3e0e3d7d78fd9929f7566fe97' => 'Zagolovok',
  '22307874c55dd88c4737a545ae0c4969437d170d' => 'Language',
  '4338ca1a07b9a0f9ae8f5e3371a1324f29ca86fc' => 'About us',
  '24b45e86d53972809ab379abd6b5fbab65260cf2' => 'Tours',
  '9660a82876a81a983eb45391928d948fb19f6e94' => 'Excursions',
  '4166d94fda800fdf4aaecc94735ec4241403f707' => 'Home',
);