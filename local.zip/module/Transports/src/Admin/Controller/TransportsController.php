<?php
namespace TransportsAdmin\Controller;

use Aptero\Mvc\Controller\Admin\AbstractActionController;
use Aptero\Service\Admin\TableService;

class TransportsController extends AbstractActionController
{

}