<?php
namespace TransportsAdmin\Service;

use Aptero\Service\Admin\TableService;

class TransportsService extends TableService
{

}