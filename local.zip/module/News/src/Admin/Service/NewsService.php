<?php
namespace NewsAdmin\Service;

use Aptero\Service\Admin\TableService;

class NewsService extends TableService
{

}