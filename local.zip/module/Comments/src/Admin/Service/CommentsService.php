<?php
namespace CommentsAdmin\Service;

use Aptero\Service\Admin\TableService;

class CommentsService extends TableService
{

}