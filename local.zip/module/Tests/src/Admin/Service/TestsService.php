<?php
namespace TestsAdmin\Service;

use Aptero\Service\Admin\TableService;

class TestsService extends TableService
{

}