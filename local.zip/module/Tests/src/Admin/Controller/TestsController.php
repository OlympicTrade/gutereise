<?php
namespace TestsAdmin\Controller;

use Aptero\Mvc\Controller\Admin\AbstractActionController;
use Aptero\Service\Admin\TableService;

class TestsController extends AbstractActionController
{

}