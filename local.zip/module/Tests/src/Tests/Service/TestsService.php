<?php

namespace Tests\Service;

use Aptero\Service\AbstractService;

class TestsService extends AbstractService
{

}