<?php
namespace ReviewsAdmin\Service;

use Aptero\Service\Admin\TableService;

class ReviewsService extends TableService
{

}