<?php
namespace ApplicationAdmin\Service;

use Aptero\Service\Admin\TableService;

class RegionsService extends TableService
{

}