<?php
namespace ApplicationAdmin\Service;

use Aptero\Service\Admin\TableService;

class SettingsService extends TableService
{

}