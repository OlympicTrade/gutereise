<?php
namespace ApplicationAdmin\Controller;

use ApplicationAdmin\Model\Content;
use Aptero\Mvc\Controller\Admin\AbstractActionController;

use Aptero\Service\Admin\TableService;

class RegionsController extends AbstractActionController
{

}