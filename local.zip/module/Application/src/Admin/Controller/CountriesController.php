<?php
namespace ApplicationAdmin\Controller;

use Aptero\Mvc\Controller\Admin\AbstractActionController;

class CountriesController extends AbstractActionController
{

}