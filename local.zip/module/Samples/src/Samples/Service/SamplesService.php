<?php

namespace Samples\Service;

use Aptero\Service\AbstractService;

class SamplesService extends AbstractService
{

}