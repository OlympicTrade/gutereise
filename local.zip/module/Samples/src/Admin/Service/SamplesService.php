<?php
namespace SamplesAdmin\Service;

use Aptero\Service\Admin\TableService;

class SamplesService extends TableService
{

}