<?php
namespace SamplesAdmin\Controller;

use Aptero\Mvc\Controller\Admin\AbstractActionController;
use Aptero\Service\Admin\TableService;

class SamplesController extends AbstractActionController
{

}