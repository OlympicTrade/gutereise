<?php
namespace HotelsAdmin\Service;

use Aptero\Service\Admin\TableService;

class HotelsService extends TableService
{

}