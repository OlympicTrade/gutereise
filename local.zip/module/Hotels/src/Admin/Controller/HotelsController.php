<?php
namespace HotelsAdmin\Controller;

use Aptero\Mvc\Controller\Admin\AbstractActionController;

class HotelsController extends AbstractActionController
{
    public function indexAction()
    {
        dd('qweqwe');
    }
}