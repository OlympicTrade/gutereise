<?php

namespace Aptero\Form\Element\Admin;

use Zend\Form\Element;

class Collection extends Element
{
    protected $attributes = array(
        'type' => 'filemanager',
    );
}
