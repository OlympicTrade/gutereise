<?php

namespace Aptero\Form\Element\Admin;

use Zend\Form\Element;

class ExercisesImages extends Element
{
    protected $attributes = array(
        'type' => 'filemanager',
    );
}
