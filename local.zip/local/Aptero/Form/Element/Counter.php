<?php
namespace Aptero\Form\Element;

use Zend\Form\Element;

class Counter extends Element
{
    protected $attributes = array(
        'type' => 'text',
    );
}
