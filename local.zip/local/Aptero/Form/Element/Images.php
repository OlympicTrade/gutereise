<?php

namespace Aptero\Form\Element;
use Zend\Form\Element;

class Images extends Element
{
    protected $attributes = array(
        'type' => 'image',
    );
}
