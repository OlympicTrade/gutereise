<?php
namespace Aptero\Db\Entity\Filters;

class Text extends AbstractFilter
{

}