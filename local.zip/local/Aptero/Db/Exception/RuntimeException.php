<?php
namespace Aptero\Db\Exception;

class RuntimeException extends \Aptero\Exception\Exception
{
}
