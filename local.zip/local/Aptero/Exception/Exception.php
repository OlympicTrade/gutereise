<?php
namespace Aptero\Exception;

class Exception extends \Exception
{

}
